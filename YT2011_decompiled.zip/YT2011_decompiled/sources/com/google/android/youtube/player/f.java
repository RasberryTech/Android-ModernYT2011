package com.google.android.youtube.player;

import android.content.Context;
import android.view.SurfaceView;

/* JADX INFO: loaded from: classes.dex */
final class f extends SurfaceView {
    private /* synthetic */ YouTubePlayer a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(YouTubePlayer youTubePlayer, Context context) {
        super(context);
        this.a = youTubePlayer;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x006b  */
    @Override // android.view.SurfaceView, android.view.View
    protected final void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int defaultSize = getDefaultSize(this.a.e, i);
        int defaultSize2 = getDefaultSize(this.a.f, i2);
        if (this.a.e <= 0 || this.a.f <= 0) {
            i3 = defaultSize;
            i4 = defaultSize2;
        } else if (this.a.e * defaultSize2 > this.a.f * defaultSize) {
            i3 = defaultSize;
            i4 = (this.a.f * defaultSize) / this.a.e;
        } else if (this.a.e * defaultSize2 < this.a.f * defaultSize) {
            i3 = (this.a.e * defaultSize2) / this.a.f;
            i4 = defaultSize2;
        } else {
            i3 = defaultSize;
            i4 = defaultSize2;
        }
        setMeasuredDimension(i3, i4);
    }
}
